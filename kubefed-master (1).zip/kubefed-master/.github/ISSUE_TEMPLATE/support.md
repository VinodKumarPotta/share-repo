---
name: Support Request
about: Support request or question relating to KubeFed

---

<!--
STOP -- PLEASE READ!

GitHub is not the right place for support requests.

You can post your question on the [Kubernetes Slack](http://slack.k8s.io/) in the channel of `#sig-multicluster` to discuss KubeFed issues.

-->

<!-- DO NOT EDIT BELOW THIS LINE -->

/triage support
