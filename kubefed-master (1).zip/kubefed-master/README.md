# Kubernetes Cluster Federation (archived)

This repository has been archived and is no longer active development. Please
see the [current subprojects](https://github.com/kubernetes/community/tree/master/sig-multicluster#subprojects)
of SIG Multicluster to track ongoing work.

See [this discussion](https://groups.google.com/g/kubernetes-sig-multicluster/c/lciAVj-_ShE) for context.