// +build tools

package tools

import (
	_ "github.com/go-bindata/go-bindata/v3/go-bindata"
	_ "sigs.k8s.io/controller-tools/cmd/controller-gen"
)
